import React from 'react';

function Menu() {
  const items = [
    { name: 'Greek Salad', price: '$10' },
    { name: 'Bruschetta', price: '$8' },
    { name: 'Lemon Chicken', price: '$12' },
  ];

  return (
    <section id="menu" className="menu">
      <h2>Our Menu</h2>
      <ul>
        {items.map((item, index) => (
          <li key={index}>
            {item.name} - {item.price}
          </li>
        ))}
      </ul>
    </section>
  );
}

export default Menu;