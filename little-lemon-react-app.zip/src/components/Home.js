import React from 'react';

function Home() {
  return (
    <section id="home" className="home">
      <h2>Welcome to Little Lemon!</h2>
      <p>We serve delicious Mediterranean food made with fresh ingredients.</p>
    </section>
  );
}

export default Home;