import React, { useState } from 'react';

function ReservationForm() {
  const [name, setName] = useState('');
  const [guests, setGuests] = useState(1);
  const [date, setDate] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Reservation confirmed for ${name} on ${date} for ${guests} guest(s).`);
  };

  return (
    <section id="reservation" className="reservation">
      <h2>Make a Reservation</h2>
      <form onSubmit={handleSubmit}>
        <label>Name:</label>
        <input value={name} onChange={(e) => setName(e.target.value)} required />

        <label>Number of Guests:</label>
        <input type="number" min="1" value={guests} onChange={(e) => setGuests(e.target.value)} required />

        <label>Date:</label>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} required />

        <button type="submit">Reserve</button>
      </form>
    </section>
  );
}

export default ReservationForm;