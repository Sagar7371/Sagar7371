import React from 'react';

function Navbar() {
  return (
    <nav className="navbar">
      <h1>Little Lemon</h1>
      <ul>
        <li><a href="#home">Home</a></li>
        <li><a href="#menu">Menu</a></li>
        <li><a href="#reservation">Reservation</a></li>
      </ul>
    </nav>
  );
}

export default Navbar;