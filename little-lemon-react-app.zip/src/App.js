import React from 'react';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Menu from './components/Menu';
import ReservationForm from './components/ReservationForm';

function App() {
  return (
    <div>
      <Navbar />
      <Home />
      <Menu />
      <ReservationForm />
    </div>
  );
}

export default App;